import { NextResponse } from 'next/server';
import { activateNextSeason } from '@/app/actions/season-cycle';

/**
 * @fileOverview Серверная точка входа для смены сезона.
 * Защищена секретным токеном CRON_SECRET.
 * Использует новую логику активации из season-cycle.ts.
 */

export async function GET(request: Request) {
  const authHeader = request.headers.get('authorization');
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return new NextResponse('Unauthorized', { status: 401 });
  }

  try {
    const result = await activateNextSeason();
    return NextResponse.json({ 
      success: true, 
      timestamp: new Date().toISOString(),
      ...result 
    });
  } catch (error: any) {
    console.error('[CRON SEASON TRANSITION ERROR]:', error.message);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
